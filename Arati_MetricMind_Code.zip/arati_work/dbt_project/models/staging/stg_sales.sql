-- Arati - Day 4-6: dbt staging model
-- Cleans + standardizes raw data:
--   - de-duplicates on order_id (flags found in Day 3 QA)
--   - drops rows with missing critical fields (e.g. blank region)
--   - casts types and trims text fields

with dedup as (
    select
        *,
        row_number() over (
            partition by order_id
            order by order_date
        ) as _row_num
    from {{ ref('raw_sales') }}
),

cleaned as (
    select
        order_id,
        cast(order_date as date)              as order_date,
        trim(region)                          as region,
        trim(country)                         as country,
        trim(product_category)                as product_category,
        trim(product_name)                    as product_name,
        trim(sales_channel)                   as sales_channel,
        cast(units_sold as integer)           as units_sold,
        cast(unit_price as decimal(10, 2))    as unit_price,
        cast(revenue as decimal(12, 2))       as revenue,
        cast(material_cost as decimal(12, 2)) as material_cost,
        cast(shipping_cost as decimal(12, 2)) as shipping_cost,
        cast(other_cost as decimal(12, 2))    as other_cost,
        cast(total_cost as decimal(12, 2))    as total_cost
    from dedup
    where _row_num = 1            -- drop duplicate order_ids
      and region is not null and trim(region) != ''
      and country is not null and trim(country) != ''
)

select * from cleaned
