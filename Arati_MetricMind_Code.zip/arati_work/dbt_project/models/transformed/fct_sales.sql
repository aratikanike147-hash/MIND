-- Arati - Day 4-5: Transformed analytical fact table
-- Final table the Semantic Layer (Cube.dev) maps its
-- Revenue / Cost / Margin measures onto.

select
    order_id,
    order_date,
    date_trunc('quarter', order_date)  as order_quarter,
    date_trunc('month', order_date)    as order_month,
    region,
    country,
    product_category,
    product_name,
    sales_channel,
    units_sold,
    unit_price,
    revenue,
    material_cost,
    shipping_cost,
    other_cost,
    total_cost,
    (revenue - total_cost)                          as margin,
    round(
        case when revenue = 0 then 0
        else (revenue - total_cost) / revenue * 100
        end, 2
    )                                                as margin_pct
from {{ ref('stg_sales') }}
