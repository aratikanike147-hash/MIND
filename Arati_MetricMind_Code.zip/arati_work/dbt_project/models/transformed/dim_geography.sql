-- Arati - Day 5: Geography dimension
-- Supports Sravani's Regional Margin / European Sales metrics (Day 6 tests)
-- and the final demo question: "Why did our European margins drop?"

select distinct
    region,
    country
from {{ ref('stg_sales') }}
order by region, country
