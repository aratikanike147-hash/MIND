-- Arati - Day 5: Time dimension
-- Supports Sravani's Time dimensions and Q3 Revenue metric tests (Day 6).

select distinct
    order_date,
    date_trunc('quarter', order_date) as quarter,
    date_trunc('month', order_date)   as month,
    strftime('%Y', order_date)        as year
from {{ ref('stg_sales') }}
order by order_date
