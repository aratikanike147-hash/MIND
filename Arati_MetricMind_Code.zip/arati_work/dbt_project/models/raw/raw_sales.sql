-- Arati - Day 4: dbt raw model
-- Straight passthrough of the loaded source table.
-- Point this at the real Snowflake source once connected.

select
    order_id,
    order_date,
    region,
    country,
    product_category,
    product_name,
    sales_channel,
    units_sold,
    unit_price,
    revenue,
    material_cost,
    shipping_cost,
    other_cost,
    total_cost
from {{ source('metricmind', 'raw_sales') }}
