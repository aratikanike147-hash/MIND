"""
Arati - Day 3, 6, 11, 16, 18, 23: Data validation & reconciliation.

Checks the raw data for:
  - duplicate order_ids
  - missing/blank critical fields
  - incorrect values (negative revenue/cost, revenue math mismatch)

Also reconciles staged/transformed row counts against the raw source,
which Arati repeats across the project (Day 11, 19, 23, 29).
"""

import sqlite3
import pandas as pd
import os
import sys

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "metricmind.db")
CSV_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "raw", "sales_raw.csv")


def load_raw_df():
    return pd.read_csv(CSV_PATH)


def check_duplicates(df):
    dupes = df[df.duplicated(subset=["order_id"], keep=False)]
    return dupes


def check_missing_values(df):
    critical_cols = ["order_id", "order_date", "region", "country", "revenue"]
    missing = {}
    for col in critical_cols:
        blank_mask = df[col].isna() | (df[col].astype(str).str.strip() == "")
        count = int(blank_mask.sum())
        if count:
            missing[col] = count
    return missing


def check_incorrect_values(df):
    issues = []
    neg_revenue = df[df["revenue"] < 0]
    if len(neg_revenue):
        issues.append(f"{len(neg_revenue)} rows with negative revenue")

    neg_cost = df[df["total_cost"] < 0]
    if len(neg_cost):
        issues.append(f"{len(neg_cost)} rows with negative total_cost")

    # revenue should equal units_sold * unit_price (within rounding tolerance)
    expected_revenue = (df["units_sold"] * df["unit_price"]).round(2)
    mismatch = df[(df["revenue"] - expected_revenue).abs() > 0.02]
    if len(mismatch):
        issues.append(f"{len(mismatch)} rows where revenue != units_sold * unit_price")

    return issues


def reconcile_row_counts():
    """Compares raw CSV row count vs. what's loaded in the DB table."""
    raw_df = load_raw_df()
    conn = sqlite3.connect(DB_PATH)
    db_count = pd.read_sql("SELECT COUNT(*) as n FROM raw_sales", conn).iloc[0]["n"]
    conn.close()
    return len(raw_df), int(db_count)


def run_all_checks():
    df = load_raw_df()
    report_lines = []

    dupes = check_duplicates(df)
    report_lines.append(f"Duplicate order_ids: {dupes['order_id'].nunique()} distinct IDs "
                         f"({len(dupes)} rows involved)")

    missing = check_missing_values(df)
    if missing:
        for col, count in missing.items():
            report_lines.append(f"Missing values in '{col}': {count} rows")
    else:
        report_lines.append("No missing values in critical fields.")

    issues = check_incorrect_values(df)
    if issues:
        report_lines.extend(issues)
    else:
        report_lines.append("No incorrect-value issues found.")

    raw_count, db_count = reconcile_row_counts()
    match = "MATCH" if raw_count == db_count else "MISMATCH"
    report_lines.append(f"Row count reconciliation (raw CSV vs DB): "
                         f"{raw_count} vs {db_count} [{match}]")

    return report_lines


if __name__ == "__main__":
    print("=== MetricMind Data Validation Report ===\n")
    for line in run_all_checks():
        print(f"- {line}")
